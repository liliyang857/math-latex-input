export declare const FORMULA_SELECTOR = "span.fe-formula, fe-formula.fe-formula, math-span.fe-formula";
/** 正文保留 HTML，公式转为 $...$ 文本，供富文本编辑器同步或保存。 */
export declare function serializeFormulaLatex(html: string): string;
export declare function escapeHtml(value: string): string;
/** 渲染结果位于 Shadow DOM，保存的 HTML 只包含 LaTeX。 */
export declare function formulaNodeHtml(latex: string): string;
/** 宿主清理旧富文本时，保留公式源码中的换行、反斜杠和美元符号。 */
export declare function splitFormulaNodes(html: string): string[];
export declare function isFormulaNodeHtml(html: string): boolean;
/** 去掉 TinyMCE 的离屏选区副本和公式临时属性，保存稳定的源码节点。 */
export declare function serializeFormulaContent(html: string): string;
