/** 只识别带定界符的公式；转义的美元符号保留为正文。 */
export declare function splitLatexText(text: string): Array<{
    text: string;
    latex?: string;
    display?: boolean;
}>;
/** 保留 Vue 持有的原始 Text 节点，避免插值更新后公式停留在旧值。 */
export declare function renderLatexText(root: Node, global: boolean, textChanged?: boolean): void;
/** Vue 单独移除原始文本时，清理它对应的显示节点。 */
export declare function cleanupLatexText(node: Node): void;
