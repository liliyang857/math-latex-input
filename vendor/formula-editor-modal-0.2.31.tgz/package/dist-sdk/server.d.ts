export { splitLatexText } from './latex-text.js';
/** Node/PDF 专用入口，无需 window、document、Vue 或编辑器字体。 */
export declare function renderLatexSvg(latex: string): string;
