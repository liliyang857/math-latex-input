import{renderMathJaxSvg as t}from"./mathjax-LHGrOlxt.js";import{g as r}from"./latex-text-CNw-49wp.js";function e(r){return t(r)}export{e as renderLatexSvg,r as splitLatexText};
