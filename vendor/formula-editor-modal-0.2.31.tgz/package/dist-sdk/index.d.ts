export { formulaNodeHtml, splitFormulaNodes, isFormulaNodeHtml, serializeFormulaContent, serializeFormulaLatex } from './formula-node';
export { initFormulaRendering, destroyFormulaRendering, renderLatex } from './render';
export type { FormulaRenderingOptions } from './render';
export { vLatex } from './directive';
export type FormulaSubject = 'math' | 'physics' | 'chemistry';
export interface FormulaEditorResult {
    type: 'latex' | 'img';
    latex: string;
    data: string;
    subject: FormulaSubject;
}
export interface FormulaEditorOptions {
    latex?: string;
    subject?: FormulaSubject;
    outputType?: 'latex' | 'img';
    onConfirm: (result: FormulaEditorResult) => void | Promise<void>;
    onCancel?: () => void;
}
export interface FormulaEditorHandle {
    destroy: () => void;
}
export declare function openFormulaEditor(options: FormulaEditorOptions): FormulaEditorHandle;
