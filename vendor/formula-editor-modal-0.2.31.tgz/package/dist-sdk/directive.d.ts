import type { ObjectDirective } from 'vue';
/** 用于 v-html 容器或其父容器；异步内容由 SDK 的观察器持续渲染。 */
export declare const vLatex: ObjectDirective<HTMLElement>;
