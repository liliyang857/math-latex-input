/** 应用卸载时停止全局观察，重新初始化时重新扫描页面。 */
export declare function destroyFormulaRendering(): void;
export interface FormulaRenderingOptions {
    /** 自动渲染页面正文中的 $...$ / $$...$$，默认关闭。 */
    renderLatexText?: boolean;
}
/** 初始化公式节点与可选正文渲染，重复调用安全。 */
export declare function initFormulaRendering(options?: FormulaRenderingOptions): Promise<void>;
/** 返回可插入富文本的 HTML，挂载后自动渲染，节点内保留 LaTeX 源码。 */
export declare function renderLatex(latex: string): Promise<string>;
/** 导出内嵌字体的 PNG 图片，返回可直接插入的 img HTML。 */
export declare function renderFormulaImage(latex: string): Promise<string>;
