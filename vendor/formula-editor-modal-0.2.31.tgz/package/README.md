# 公式编辑器

Vue 3 + TypeScript 的数学公式编辑弹窗组件。视觉与交互对齐
[Mathpix MathLatex SDK 的 demo](https://api.mathpix.pro/#/sdk-demo)，
编辑与渲染用 **MathLive**，公式卡片 / 符号面板用 LaTeX 描述后交由 MathLive 渲染。

## 功能

- **顶部模板库**：分类标签横向排列，内容区在「公式卡片」和「符号面板」之间切换
- **学科切换**（数学 / 物理 / 化学）放在弹窗头部右侧，切换会换掉整套分类标签与内容
- **符号面板**：476 个符号，按语义配色分组、每列 3 个按钮；带「各种格式」的按钮悬停/点击
  会展开变体浮层（分数 → 7 种写法、根号 → 6 种、括号 → 10 种……）
- **公式卡片**：卡片高度固定 56px，超尺寸公式**自动等比缩放**（超出才缩，没超出保持原尺寸）
- **编辑区**：MathLive 富文本编辑、撤销/重做、点卡片或符号插入到光标处
- 支持分数 / 根号 / 矩阵 / 多行对齐（`aligned`、`cases`）/ 化学方程式（mhchem）

## 快速开始

```bash
npm install
npm run dev      # vite --mode development --host
npm run build    # vue-tsc --noEmit && vite build
```

## 目录结构

```
src/
├─ components/
│  ├─ FormulaEditorModal.vue   弹窗外壳：头部（标题 + 学科切换）/ 模板库 / 编辑区工具条 / 底部操作
│  ├─ TemplateBrowser.vue      分类标签 + 内容区（「公式卡片」与「符号面板」互斥渲染）
│  ├─ FormulaPreview.vue       单张公式卡片的预览：渲染后量尺寸、超尺寸就等比缩放
│  ├─ SymbolPalette.vue        符号面板：列优先网格分组 + 变体浮层（Teleport 到 body）
│  └─ MathLiveField.vue        编辑区封装：懒加载 MathLive、v-model、焦点、插入
├─ lib/
│  ├─ mathlive.ts              MathLive 懒加载 + 全局配置（本地字体 / 静音 / 中文）
│  ├─ templates.ts             分类标签配置 + 公式卡片数据
│  ├─ symbols.ts               符号面板数据（476 + 学科专属）
│  └─ latex.ts                 粘贴进来的定界符清洗
├─ styles/global.css           `--fe-*` 设计变量（覆盖即可换肤）
└─ App.vue                     演示页
```

## 符号面板：与 Mathpix 逐项对齐

从 `https://api.mathpix.pro/#/sdk-demo` 的编辑器 iframe（与主文档同源）里实测到的数量与排布，
本项目**逐个 tab 对齐**：

| tab | 按钮数 | 分组（每组按钮数） |
| --- | --- | --- |
| 常用 | 35 | 3·4·2·6·6·6·6·2 |
| 运算 | 46 | 17·10·4·13·2 |
| 关系 | 44 | 13·11·13·7 |
| 箭头 | 66 | 23·15·12·16 |
| 希腊 | **132** | 54·26·26·26 |
| 矩阵 | 23 | 6·4·4·4·5 |
| 上下标 | 46 | 46 |
| 大型运算 | 41 | 9·9·13·2·4·4 |
| 函数 | 25 | 5·6·6·6·2 |
| 双曲三角函数 | 18 | 6·6·6 |
| **合计** | **476** | |

> 数学 / 物理 / 化学**三个模式共用这整套标签**（物理额外多一个「物理量」、
> 化学额外多「化学物质 / 化学离子 / 化学元素 / 化学符号」）。

三个值得记录的发现：

1. **他们的按钮一半是纯文本，一半是内联 base64 PNG。**
   `运算 / 关系 / 箭头 / 希腊` 这四栏是 `<span>` 里直放 Unicode 字符（`+`、`══`、`←`、`Α`），
   可以直接读出来；结构类符号（矩阵 / 上下标 / 函数…）才是定长 PNG 位图，拿不到 LaTeX。
   本项目统一用 LaTeX 描述交给 MathLive 渲染 —— 能跟主题走、能二次编辑、不搬二进制资源。
2. **「希腊」栏有 132 个，不是 24 个。**
   = 54 个希腊字母（24 大写 + 24 小写 + 6 个小写变体 `ϵ ϑ ϖ ϱ ς ϕ`）
   + `\mathbb{A}`…`\mathbb{Z}` + `\mathcal{A}`…`\mathcal{Z}` + 26 个斜体 `a`…`z`。
   后三组是按 `getComputedStyle().fontFamily` 认出来的（`KaTeX_AMS` / `KaTeX_Caligraphic` / `KaTeX_Math`）。
3. **按钮排布是「每列 3 个」的列优先网格**，组内间距小、组间距大。
   实现见 `SymbolPalette.vue` 的 `grid-auto-flow: column` + `grid-template-rows: repeat(3, 50px)`。
   改成默认的横向填充，46 个符号会横着铺成一长条，观感差很远。

## 踩过的坑

### 公式卡片被裁：根因是网格行高，不是公式太高

卡片里的公式显示不全，第一反应是「卡片不够高」。实际量出来的是：

```
gridTemplateRows: "35.6562px × 6"     ← 6 行全挤进 268px 里
卡片高 36px（应该 ~99）· 标题 2px · 公式 0px
```

`.fe-cards` 用默认的 `grid-auto-rows: auto`，而卡片带 `overflow: hidden` ——
**它的 min-content 高度会被算成 0**，于是 auto 行按「内容接近 0」定尺寸，行被压扁、
卡片跟着压扁、公式就被裁了。修法是给行高一个**定值**（`grid-auto-rows: 100px`）。

两个反直觉的副作用，都踩过：

- 网格 `scrollHeight === clientHeight`，看起来「刚好放得下、不需要滚动」，**其实卡片里是空的**
- `getComputedStyle(卡片体).height` 返回的是被 flex 压缩后的**使用值**（6.875px），
  不是你写的 `58px`，看它会被带偏

另外 `.fe-card-body` 必须写 `flex: none`：卡片是纵向 flex，它是子项、默认 `flex-shrink: 1`，
叠上 `overflow: hidden`（min-content 高度算成 0）同样会把它挤没。

### MathLive 的静态元素是懒渲染的

`<math-span>` 对视口外的元素不渲染（`offsetHeight === 0`）。这是性能优化，不是 bug。
但它会让验证脚本产生**假通过**：只断言「是否溢出」时，尺寸为 0 的公式算出来
`0 - 卡片高` 也是负数，于是报告「零裁切全通过」。

验证时必须**先把容器滚一遍**再断言，并且断言里同时包含「尺寸 > 0」。

### 量尺寸用 `offsetWidth/offsetHeight`，不要用 `getBoundingClientRect()`

后者返回的是**缩放后**的尺寸。用它去算缩放比会越缩越小。`FormulaPreview.vue` 里
还有一层：不能只量一次 —— MathLive 渲染完成、字体到位都会改布局，一次测量量到的是中间态，
所以挂了 `ResizeObserver` 自动重算。

## 验证方式

零额外依赖：写一个 `_*.mjs` 临时脚本，起一个静态服务器 + 无头 Chrome，通过 CDP 驱动页面并断言
（本机 Bash 缺 `dirname`/`head`/`tail`，所以脚本用 Node 写、用 PowerShell 起）。
**这类脚本用完即删**（已加进 `.gitignore`），不要留在仓库里。

固定检查项：符号按钮数 / 渲染数 / 变体浮层 / 插入是否落到编辑区 / 公式卡片是否被裁 /
零 `render-error` / 零 exception / 零 `console.error`。
