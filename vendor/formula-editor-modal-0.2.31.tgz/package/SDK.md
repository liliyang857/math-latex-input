# 公式编辑器 SDK

SDK 在本项目维护，使用方只安装打包产物，不复制组件源码。适用于浏览器和 Vue 3.5 项目，无需 CDN。

## 构建与安装

0.2.26 弹窗底部预览与模板卡片预览改用 MathJax 3 的 TeX → SVG，与正文同一条渲染链路、同一套判据。
此前预览用 MathLive 的 `<math-span>`：MathLive 面向交互输入必须容错，`\left` 没等到 `\right`
时会补一个不可见定界符继续排版，而正文的 MathJax 严格校验后判定失败并回退成源码 ——
于是出现「预览正常、插入正文变源码」，录入时无法发现。现在预览遇到 `data-mjx-error`
就显示 LaTeX 源码（警示色 + title 说明），所见即正文所得。

0.2.16 全局 LaTeX 渲染覆盖 TinyMCE 的 `.mce-content-body` 正文，直接插入公式节点，
不生成 Vue 展示副本；`serializeFormulaLatex(editor.getContent())` 仍输出 LaTeX 文本。
其他可编辑区、代码、表单输入及显式排除区域保持不转换。

0.2.15 新增 `destroyFormulaRendering()`：应用卸载时停止全局公式观察器，
随后可再次调用 `initFormulaRendering` 初始化。Vue 应用可在共享插件中启用
`initFormulaRendering({ renderLatexText: true })` 并在 `app.onUnmount` 清理。

```sh
npm run test:sdk
npm run build:sdk
npm pack
# 使用方：将包复制到 vendor 后安装
pnpm add ./vendor/formula-editor-modal-0.2.13.tgz
```

安装或更新后重启使用方的开发服务。发布新包需提升版本，避免同名 tgz 缓存。

0.2.14 新增 `serializeFormulaLatex(html)`：富文本编辑器通过 `getContent()` 获取 HTML 后调用，正文保留 HTML，公式节点（包括带 `data-latex` 的 SDK 图片）转换为 `$...$` 文本，并移除 TinyMCE 离屏选区副本。存量 WIRIS 图片保持原样。原 `serializeFormulaContent` 继续保留公式节点，兼容已有调用方。

```ts
import { serializeFormulaLatex } from 'formula-editor-modal'
const value = serializeFormulaLatex(editor.getContent())
// <p>求 $x^2$ 的值</p>
```

0.2.10 在原有四个样式快捷按钮旁增加“字形调整”下拉框：默认、正体、粗体、斜体、无衬线、等宽、黑板粗体、花体、哥特体。有选区时修改所选内容，无选区时作用于后续输入，支持撤销重做；样式写入 LaTeX，渲染和导出均保留。LaTeX 源码模式下禁用。数学字形的字符覆盖取决于所选变体，例如花体优先用于大写字母。

0.2.9 将 LaTeX 公式节点改为正文基线对齐，避免公式数字与普通数字上下错位。图片模式保持原有对齐方式，保存格式不变。

0.2.8 在可视化编辑区提供“正体、斜体、正粗、斜粗”按钮：有选区时修改选中内容，无选区时用于后续输入，支持撤销和重做。样式随 LaTeX 保存并渲染；LaTeX 源码模式下这四个按钮禁用。

“常用”符号面板的分段函数、多行对齐（`aligned`）与矩阵共用 5×5 行列选择器，可选 1–5 行、1–5 列，插入可填写的单元格。分段函数带左花括号，多行对齐按 `aligned` 规则对齐。每行用 `&` 分列，用 `\\` 换行；方块可直接填写。可视化编辑时，在当前行内按 Enter 可在其后增加一行，并将光标移入新行，支持撤销与重做。

从 0.2.5 起，页面展示及 `renderLatex` 使用 MathJax 3 的 TeX → SVG 引擎。标准公式 span 的 Shadow DOM 内生成 `<mjx-container jax="SVG"><svg>…</svg></mjx-container>`，字形路径自包含，无需 CDN 或额外字体。支持 AMS 分段/矩阵、颜色及 mhchem 化学式；弹窗编辑仍使用 MathLive，图片返回模式保持原有 PNG 输出。数据库继续保存 LaTeX，展示 SVG 不进入保存内容。

0.2.6 使用 Terser 压缩 SDK，MathLive 字体只打包一份，首次打开编辑器时加载；PNG 导出复用同一份字体。普通页面仅渲染公式时无需加载 MathLive 编辑器及字体。请部署完整的 `dist-sdk`，保留动态加载的 JS 文件。构建后可运行 `node --test tests/sdk-size.test.mjs` 检查体积及字体去重。

## 打开弹窗与返回数据

服务端 PDF 渲染请使用独立的 Node 入口（0.2.7 起提供），无需引入浏览器 SDK 或样式：

```ts
import { renderLatexSvg, splitLatexText } from 'formula-editor-modal/server'
const html = renderLatexSvg('\\frac{1}{2}') // 自包含的 MathJax SVG，适合插入导出文档
const parts = splitLatexText('题干 $x^2$') // 拆分正文和公式，在 DOM 文本节点上使用
```

浏览器端公式的 SVG 位于 Shadow DOM，`innerHTML` / `cloneNode` 不会携带它。导出服务应根据 `data-latex` 或文本里的 `$...$` / `$$...$$` 重新渲染，再截图或打印；数据库保存格式不需要改变。

编辑器打开公式、插入模板、从源码切换到可视化及确认保存时，统一将 `\begin{array}{列格式}…\end{array}` 转为 `\begin{aligned}…\end{aligned}`，去掉列格式参数，将外层连续等号自动拆行并对齐，例如 `x=a=b` 转为 `x&=a\\&=b`，确认后返回转换后的 LaTeX。原有非空行保留，分式、文本、括号及嵌套环境内部的等号不拆，已有 `&` 对齐列也保持原样。底部预览、浏览器 SDK 与 Node/PDF 渲染共用此规则；仅调用渲染函数不会修改传入的源码。

```ts
import { openFormulaEditor, renderLatex, initFormulaRendering } from 'formula-editor-modal'
import 'formula-editor-modal/style.css'

// 应用启动调用：让普通页面 v-html 中保存的 LaTeX 节点也能渲染。
await initFormulaRendering()

const handle = openFormulaEditor({
  subject: 'math',      // math 数学 / physics 物理 / chemistry 化学，默认 math
  outputType: 'latex',  // latex / img，默认 latex
  latex: '',           // 初始源码；双击编辑时传入节点的 data-latex
  async onConfirm(result) {
    const html = result.type === 'latex'
      ? await renderLatex(result.data)
      : result.data
    editor.insertContent(html)
  },
  onCancel() {},
})

// 宿主销毁时清理弹窗。
handle.destroy()
```

返回结构：`{ type: 'latex' | 'img', latex: string, data: string, subject: 'math' | 'physics' | 'chemistry' }`。

- `latex` 始终是裸 LaTeX 源码，便于再次编辑。
- `type: 'latex'`：`data` 是裸 LaTeX；调用 `await renderLatex(data)` 得到标准 span HTML。插入 DOM 后自动渲染，不生成图片。
- `type: 'img'`：`data` 是完整 `<img>` HTML（PNG data URL），含 `data-latex`，直接插入和保存。SDK 图片 class 为 `fe-formula-image`，自动上传/压缩等流程应跳过此类图片。
- 支持异步 `onConfirm`：插入成功后才关闭弹窗；失败时显示错误并保留输入，可重试。

## 独立渲染 LaTeX

```ts
const html = await renderLatex(String.raw`x=\frac{-b\pm\sqrt{b^2-4ac}}{2a}`)
container.innerHTML = html
```

节点格式：

```html
<span class="fe-formula" data-latex="x^2" contenteditable="false" style="display:inline-block;vertical-align:baseline;">x^2</span>
```

渲染位于 Shadow DOM，保存 HTML 只包含 LaTeX。其他展示系统也需安装 SDK 并调用 `initFormulaRendering()`；不接入时显示源码文本。

公式继承正文的 `font-size`，不设置公式整体缩放，例如父容器设置 `font-size: 14px` 时，14px 表示基础字符字号，并非整条公式的高度。公式采用完整字号的数学排版，普通 `\frac` 的分子、分母不再因行内模式缩到约 9.9px，容器仍在正文中行内显示。分式、根号、矩阵按数学排版自然撑开；上下标与嵌套分式保留正常的字号比例，显式 `\textstyle` / `\tfrac` 仍遵循源码。SVG 尺寸使用 `em`，不会因正文切换字体而改变公式大小。编辑弹窗底部预览使用相同排版规则和 14px 基础字号，超出区域时滚动，不缩小整条公式。

## 自动渲染正文中的 LaTeX

接口返回的富文本可直接包含 `$x^2$`、`$$\frac{a}{b}$$`，无需先转换成图片或公式节点。

全项目自动渲染（应用启动调用一次）：

```ts
import { initFormulaRendering, vLatex } from 'formula-editor-modal'
import 'formula-editor-modal/style.css'

app.directive('latex', vLatex)
void initFormulaRendering({ renderLatexText: true }).catch(console.error)
```

开启后自动处理当前页面、异步接口内容、列表翻页、弹窗和 Vue 文本更新；无需逐个修改 `v-html`。只修改显示 DOM，不修改接口对象或表单值。默认 `initFormulaRendering()` 仅渲染公式节点，保留之前的行为。

只渲染指定区域时，不开启全局开关，注册指令后使用：

```html
<div v-latex v-html="question.title"></div>
<!-- 也可标记父容器，自动处理内部异步添加的内容 -->
<section v-latex><QuestionDetail /></section>
<!-- 全局渲染时排除一个区域 -->
<div data-fe-latex-ignore>此处 $x$ 保持源码</div>
```

自动跳过输入框、可编辑区域、TinyMCE、公式编辑弹窗、代码块及已有公式节点和图片。不解析 HTML 属性。`\$` 不作为公式定界符；没有定界符的裸字符串（例如 `x^2`）应显式调用 `renderLatex()`。公式需位于同一个文本节点内，不支持用 HTML 标签拆开一条公式。不要将自动渲染后的展示 DOM 直接作为保存内容；保存原始接口数据，或使用编辑器专用的序列化流程。

## TinyMCE 接入要点

SDK 不依赖 TinyMCE，不再注册 TinyMCE 按钮。由使用方注册按钮和双击事件：

1. 点击按钮新增时先聚焦编辑器并折叠选区，再记录 `editor.selection.getBookmark(1)`，然后调用 `openFormulaEditor()`。TinyMCE 5 的 `getBookmark(2, true)` 会把不可编辑公式旁的光标还原成公式选区，导致下次插入覆盖旧公式。
2. 确认后根据 `result.type` 调用渲染函数或直接使用图片 HTML；恢复书签，在 `undoManager.transact()` 内插入，触发 `input`、`change` 回写表单。
3. 双击 `span.fe-formula` 或 `img.fe-formula-image` 时，取 `data-latex` 传回弹窗；确认后选择原节点并替换，图片继续使用 `outputType: 'img'`。
4. 无需设置 custom_elements；标准 `span`、`img` 需允许 `class`、`data-latex`、`contenteditable`、`style` 等属性。
5. 保存 `body.innerHTML` 前调用 `serializeFormulaContent(html)`，移除 TinyMCE 离屏选区副本，规范 LaTeX 节点。不会将图片转为 LaTeX。
6. 旧内容处理（例如转换字面量 `\n`、识别 `$...$`）前调用 `splitFormulaNodes(html)`，跳过 `isFormulaNodeHtml(part)` 为真的片段；LaTeX 节点回填时用 `renderLatex()`，图片原样返回。

TinyMCE 5 还需排除 SDK 图片的自动 data URL 转 blob 转换，否则保存的临时 blob 地址会失效：

```ts
images_dataimg_filter: image => !image.classList.contains('fe-formula-image')
```

业务侧的 MutationObserver 图片上传逻辑也需跳过 `img.fe-formula-image`。

`serializeFormulaContent` 兼容 0.1.x 的 `math-span` / `fe-formula` 标签，转换为标准 span。升级后不要保留旧的自定义标签配置。

## 边界

自动渲染按单个公式隔离错误：MathJax 抛错或返回错误节点时，该公式保留原始 LaTeX，不改写源码，同批后续公式继续渲染。相同节点的相同失败源码不重复尝试；修改 `data-latex` 后自动重试。

服务端 HTML 清洗需允许上述属性及图片 data URL。PNG 会增大保存内容；如果接口限制长度，应由使用方另行上传图片。Word/PDF 导出对 Shadow DOM 的支持需单独验证。已经丢失源码的 `null>` 无法恢复。

## 本地示例

先运行 `npm run build:sdk`、`npm run dev`，打开 `/sdk-demo.html`。可以选择学科、返回类型、初始 LaTeX，查看回调数据和实际渲染结果。

浏览器回归自检：打开 `/tests/sdk-rendering.html`，验证指令范围、全局渲染、异步更新、编辑区域排除、Vue 文本及列表更新和卸载。
